export const htmlAddForm =  `<tr id='addform' style="display:none" >
<td>
    <input type="number" name="id" id="inputId" placeholder="Student Id" required>
</td>
<td>                   
    <input type="text" name="id" id="firstName" placeholder="First Name" required>
</td>
<td>
    <input type="text" name="id" id="lastName" placeholder="Last Name" required>
</td>
<td>
    <input type="text" name="id" id="facultyNumber" placeholder="Faculty Number" required>
</td>
<td>
    <input type="number" name="id" id="grade" placeholder="Grade" required>
    <button id="submit">Add</button>
</td>
</tr>`